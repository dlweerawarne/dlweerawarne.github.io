File name: 	BU.sty	
Description: 	This style file specifies all the content formatting. Binghamton University graduate school dissertation formattings have been incorporated.
Required modifications:	
			\graphicspath{{PATH:/TO/FIGURE/FOLDER/}}
			Submission statement 
			Acceptance Statement

File name:		BU.tex 	
Description: 	This file contains most of the user specific inputs such as title, committee members, etc. Also, this specifies all the chapter files that should be included in the body.     
Required modification: 
			Self explanatory 

File name:		ToCLoTLoF.tex 
Description: 	This file specifies the content of TOC.

File name:		Bibliography.tex 
Description: 	This file specifies the bibliography style and bibtex file name.
Required modification: 
			If different bibliography style is needed, specify the style name under \bibliographystyle and copy and past the .bst file into the same folder.

File name: 	osajnl.bst 
Description:	Bibliography style file (Provided by Optical Society of America)
Required modification: 
			If different bibliography style is needed, specify the style name under \bibliographystyle and copy and past the .bst file into the same folder.

Any questions and comments dweeraw1@binghamton.edu



 

